// js/api.js
const API_BASE_URL = 'http://localhost:3001';

class ApiService {
    constructor() {
        this.token = localStorage.getItem('authToken');
    }

    async request(endpoint, options = {}) {
        const url = `${API_BASE_URL}${endpoint}`;
        const config = {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers,
            },
            ...options
        };

        if (this.token) {
            config.headers['Authorization'] = `Bearer ${this.token}`;
        }

        if (options.body) {
            config.body = JSON.stringify(options.body);
        }

        try {
            const response = await fetch(url, config);

            if (response.status === 401) {
                // Token expirado ou inválido
                this.logout();
                throw new Error('Sessão expirada. Faça login novamente.');
            }

            if (!response.ok) {
                // Tenta extrair a mensagem de erro do backend, se houver
                let errorMsg = 'Erro na requisição';
                try {
                    const errorData = await response.json();
                    errorMsg = errorData.message || errorMsg;
                } catch (e) {
                    // Se não conseguir parsear JSON, usa status text
                    errorMsg = response.statusText || errorMsg;
                }
                throw new Error(errorMsg);
            }

            // Para respostas sem conteúdo (como 204 No Content)
            if (response.status === 204) {
                return null;
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }

    setToken(token) {
        this.token = token;
        localStorage.setItem('authToken', token);
    }

    logout() {
        this.token = null;
        localStorage.removeItem('authToken');
        localStorage.removeItem('usuario');
        window.location.href = 'login.html';
    }

    // Métodos de Autenticação
    async login(email, senha) {
        const data = await this.request('/auth/login', {
            method: 'POST',
            body: { email, senha },
        });
        
        if (data.access_token) {
            this.setToken(data.access_token);
            localStorage.setItem('usuario', JSON.stringify(data.usuario));
        }
        return data;
    }

    async registrar(usuarioData) {
        return this.request('/auth/registrar', {
            method: 'POST',
            body: usuarioData,
        });
    }

    // Métodos de Agendamento (AJUSTADOS para seus endpoints)
    async getBarbeiros() {
        return this.request('/api/barbeiros');
    }

    async getServicos() {
        return this.request('/api/servicos');
    }

    async getHorariosDisponiveis(barbeiroId, data) {
        return this.request(`/api/agendamentos/horarios?barbeiroId=${barbeiroId}&data=${data}`);
    }

    async criarAgendamento(agendamentoData) {
        return this.request('/api/agendamentos', {
            method: 'POST',
            body: agendamentoData,
        });
    }

    async getMeusAgendamentos() {
        return this.request('/api/meus-agendamentos');
    }

    async cancelarAgendamento(id) {
        return this.request(`/api/agendamentos/${id}`, {
            method: 'DELETE',
        });
    }

    // Métodos alternativos baseados nos que você já tinha
    async listarAgendamentos() {
        return this.request('/agendamentos');
    }

    async listarServicos() {
        return this.request('/servicos');
    }
}

// Disponibiliza globalmente para ser usado em outros arquivos
window.apiService = new ApiService();