class BarbeariaApp {
    constructor() {
        this.apiService = window.apiService;
        this.usuario = JSON.parse(localStorage.getItem('usuario') || 'null');
        this.init();
    }

    init() {
        this.verificarAutenticacao();
        this.inicializarEventListeners();
    }

    verificarAutenticacao() {
        const paginaPublica = ['index.html', 'login.html', 'register.html'].includes(
            window.location.pathname.split('/').pop()
        );

        if (!this.usuario && !paginaPublica) {
            window.location.href = 'login.html';
        } else if (this.usuario && paginaPublica) {
            window.location.href = 'agendamentos.html';
        }
    }

    inicializarEventListeners() {
        if (document.getElementById('loginForm')) {
            document.getElementById('loginForm').addEventListener('submit', (e) => {
                e.preventDefault();
                this.fazerLogin();
            });
        }

        if (document.getElementById('registerForm')) {
            document.getElementById('registerForm').addEventListener('submit', (e) => {
                e.preventDefault();
                this.fazerRegistro();
            });
        }
    }

    async fazerLogin() {
        try {
            const email = document.getElementById('email').value;
            const senha = document.getElementById('senha').value;

            await this.apiService.login(email, senha);
            window.location.href = 'agendamentos.html';
        } catch (error) {
            alert('Erro ao fazer login: ' + error.message);
        }
    }

    async fazerRegistro() {
        try {
            const formData = {
                nome: document.getElementById('nome').value,
                email: document.getElementById('email').value,
                telefone: document.getElementById('telefone').value,
                senha: document.getElementById('senha').value,
            };

            await this.apiService.registrar(formData);
            alert('Cadastro realizado com sucesso! Faça login para continuar.');
            window.location.href = 'login.html';
        } catch (error) {
            alert('Erro ao cadastrar: ' + error.message);
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new BarbeariaApp();
});