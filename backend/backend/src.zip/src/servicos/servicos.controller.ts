import { Controller, Get, Post, Body } from '@nestjs/common';
import { ServicosService } from './servicos.service';
import { Servico } from './servico.entity';

@Controller('servicos')
export class ServicosController {
  constructor(private readonly servicosService: ServicosService) {}

  @Get()
  async listarTodos(): Promise<Servico[]> {
    return this.servicosService.encontrarTodos();
  }

  @Post()
  async criar(@Body() servicoData: Partial<Servico>): Promise<Servico> {
    return this.servicosService.criar(servicoData);
  }
}