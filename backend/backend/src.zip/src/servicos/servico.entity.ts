import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';
import { IsNotEmpty, IsNumber, IsPositive } from 'class-validator';

@Entity()
export class Servico {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  @IsNotEmpty()
  nome: string;

  @Column({ type: 'text', nullable: true })
  descricao: string;

  @Column('decimal', { precision: 10, scale: 2 })
  @IsNumber()
  @IsPositive()
  preco: number;

  @Column()
  @IsNumber()
  @IsPositive()
  duracao: number;
}