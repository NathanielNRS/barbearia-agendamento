import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Servico } from './servico.entity';

@Injectable()
export class ServicosService {
  constructor(
    @InjectRepository(Servico)
    private servicosRepository: Repository<Servico>,
  ) {}

  async encontrarTodos(): Promise<Servico[]> {
    return this.servicosRepository.find();
  }

  async encontrarPorId(id: number): Promise<Servico> {
    return this.servicosRepository.findOne({ where: { id } });
  }

  async criar(servicoData: Partial<Servico>): Promise<Servico> {
    const servico = this.servicosRepository.create(servicoData);
    return this.servicosRepository.save(servico);
  }
}