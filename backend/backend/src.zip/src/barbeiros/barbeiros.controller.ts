// src/barbeiros/barbeiros.controller.ts
import { Controller, Get, Post, Body, Param, Delete } from '@nestjs/common';
import { BarbeirosService } from './barbeiros.service';
import { Barbeiro } from './barbeiro.entity';

@Controller('api/barbeiros')
export class BarbeirosController {
  constructor(private readonly barbeirosService: BarbeirosService) {}

  @Get()
  async findAll(): Promise<Barbeiro[]> {
    return this.barbeirosService.findAll();
  }

  @Get(':id')
  async findOne(@Param('id') id: string): Promise<Barbeiro> {
    return this.barbeirosService.findOne(+id);
  }

  @Post()
  async create(@Body() barbeiroData: Partial<Barbeiro>): Promise<Barbeiro> {
    return this.barbeirosService.create(barbeiroData);
  }

  @Delete(':id')
  async remove(@Param('id') id: string): Promise<void> {
    return this.barbeirosService.remove(+id);
  }
}