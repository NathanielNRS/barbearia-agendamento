import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Agendamento } from './agendamento.entity';

@Injectable()
export class AgendamentosService {
  constructor(
    @InjectRepository(Agendamento)
    private agendamentosRepository: Repository<Agendamento>,
  ) {}

  async encontrarTodos(): Promise<Agendamento[]> {
    return this.agendamentosRepository.find({
      relations: ['usuario', 'servico'],
    });
  }

  async encontrarPorUsuarioId(usuarioId: number): Promise<Agendamento[]> {
    return this.agendamentosRepository.find({
      where: { usuario_id: usuarioId },
      relations: ['servico'],
      order: { data_agendamento: 'DESC' },
    });
  }

  async encontrarPorId(id: number): Promise<Agendamento | null> {
    return this.agendamentosRepository.findOne({
      where: { id },
      relations: ['usuario', 'servico'],
    });
  }

  async criar(agendamentoData: Partial<Agendamento>): Promise<Agendamento> {
    const agendamento = this.agendamentosRepository.create(agendamentoData);
    return this.agendamentosRepository.save(agendamento);
  }

  async atualizar(id: number, agendamentoData: Partial<Agendamento>): Promise<Agendamento> {
    await this.agendamentosRepository.update(id, agendamentoData);
    return this.encontrarPorId(id);
  }

  async cancelar(id: number): Promise<Agendamento> {
    await this.agendamentosRepository.update(id, { status: 'cancelado' });
    return this.encontrarPorId(id);
  }

  async remover(id: number): Promise<void> {
    await this.agendamentosRepository.delete(id);
  }
}