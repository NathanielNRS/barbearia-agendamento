import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Usuario } from '../usuarios/usuario.entity';
import { Servico } from '../servicos/servico.entity';
import { Barbeiro } from '../barbeiros/barbeiro.entity'; // Importação do Barbeiro
import { IsNotEmpty, IsDate } from 'class-validator';

@Entity()
export class Agendamento {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => Usuario, usuario => usuario.agendamentos)
  @JoinColumn({ name: 'usuario_id' })
  usuario: Usuario;

  @Column()
  usuario_id: number;

  @ManyToOne(() => Servico)
  @JoinColumn({ name: 'servico_id' })
  servico: Servico;

  @Column()
  servico_id: number;

  // RELAÇÃO COM BARBEIRO - SEGUINDO O MESMO PADRÃO
  @ManyToOne(() => Barbeiro)
  @JoinColumn({ name: 'barbeiro_id' })
  barbeiro: Barbeiro;

  @Column()
  barbeiro_id: number;

  @Column()
  @IsDate()
  data_agendamento: Date;

  @Column({ type: 'text', nullable: true })
  observacoes: string;

  @Column({
    type: 'enum',
    enum: ['confirmado', 'pendente', 'cancelado', 'concluido'],
    default: 'confirmado'
  })
  status: string;

  @Column({ default: () => 'CURRENT_TIMESTAMP' })
  data_criacao: Date;
}