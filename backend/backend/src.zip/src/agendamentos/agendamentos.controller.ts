import { Controller, Get, Post, Body, Param, Put, Delete, UseGuards } from '@nestjs/common';
import { AgendamentosService } from './agendamentos.service';
import { Agendamento } from './agendamento.entity';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@Controller('agendamentos')
@UseGuards(JwtAuthGuard)
export class AgendamentosController {
  constructor(private readonly agendamentosService: AgendamentosService) {}

  @Get()
  async listarTodos(): Promise<Agendamento[]> {
    return this.agendamentosService.encontrarTodos();
  }

  @Get('usuario/:usuarioId')
  async listarPorUsuario(@Param('usuarioId') usuarioId: number): Promise<Agendamento[]> {
    return this.agendamentosService.encontrarPorUsuarioId(usuarioId);
  }

  @Get(':id')
  async encontrarPorId(@Param('id') id: number): Promise<Agendamento> {
    return this.agendamentosService.encontrarPorId(id);
  }

  @Post()
  async criar(@Body() agendamentoData: Partial<Agendamento>): Promise<Agendamento> {
    return this.agendamentosService.criar(agendamentoData);
  }

  @Put(':id/cancelar')
  async cancelar(@Param('id') id: number): Promise<Agendamento> {
    return this.agendamentosService.cancelar(id);
  }

  @Delete(':id')
  async remover(@Param('id') id: number): Promise<void> {
    return this.agendamentosService.remover(id);
  }
}